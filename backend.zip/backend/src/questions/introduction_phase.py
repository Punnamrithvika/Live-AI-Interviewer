from __future__ import annotations

from ..utils.cohere_client import generate_text
from ..audio.text_to_speech import text_to_speech
from ..audio.speech_to_text import SpeechToText
from ..utils.storage import SessionStore
from ..scoring.evaluate_intro import evaluate_intro_answer


INTRO_PROMPT = "Generate a friendly interview question asking the candidate to introduce themselves briefly."


def generate_intro_question() -> str:
    return generate_text(INTRO_PROMPT) or "Can you briefly introduce yourself?"


def run_intro_interaction(store: SessionStore, play_audio: bool = True) -> None:
    question = generate_intro_question()
    text_to_speech(question, play=play_audio)

    stt = SpeechToText()
    answer = stt.listen(timeout=8.0, phrase_time_limit=60.0)

    score = evaluate_intro_answer(answer)
    store.add_qa("introduction", question, answer, score)

from __future__ import annotations

from typing import List, Dict

from ..utils.cohere_client import generate_text
from ..audio.text_to_speech import text_to_speech
from ..audio.speech_to_text import SpeechToText
from ..utils.storage import SessionStore
from ..scoring.evaluate_project import evaluate_project_answer


def generate_project_questions(projects: List[Dict[str, str]], prev_responses: List[str], total: int = 3) -> List[str]:
    project_summaries = "\n".join(f"- {p.get('project_title', '')}: {p.get('summary', '')}" for p in projects)
    prev_ctx = "\n".join(prev_responses[-2:]) if prev_responses else ""
    base_prompt = (
        "Based on these project summaries, generate interview questions.\n"
        "If only one project exists, focus all questions on it.\n"
        f"Project summaries:\n{project_summaries}\n\n"
    )
    if prev_ctx:
        base_prompt += f"Recent candidate responses (context):\n{prev_ctx}\n\n"
    base_prompt += f"Generate {total} concise questions as a bullet list."

    raw = generate_text(base_prompt)
    # Split bullets to list of questions
    qs: List[str] = []
    for line in (raw or "").splitlines():
        line = line.strip("-• ")
        if not line:
            continue
        if not line.endswith("?") and len(line) > 8:
            line += "?"
        qs.append(line)
    if len(qs) > total:
        qs = qs[:total]
    while len(qs) < total:
        qs.append("Tell me about a challenge you faced in your project and how you solved it?")
    return qs


def run_projects_interaction(store: SessionStore, play_audio: bool = True) -> None:
    projects = store.state.get("projects", [])
    prev_responses = store.get_last_responses("introduction", n=2)
    questions = generate_project_questions(projects, prev_responses, total=3)

    stt = SpeechToText()
    for q in questions:
        text_to_speech(q, play=play_audio)
        answer = stt.listen(timeout=8.0, phrase_time_limit=90.0)
        score = evaluate_project_answer(answer)
        store.add_qa("projects", q, answer, score)

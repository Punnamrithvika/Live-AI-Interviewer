from __future__ import annotations

from typing import Dict, List

from ..utils.cohere_client import generate_text
from ..audio.text_to_speech import text_to_speech
from ..audio.speech_to_text import SpeechToText
from ..utils.storage import SessionStore
from ..scoring.trained_model import score_candidate_answer_realtime as score_answer

LEVEL_PROMPTS: Dict[str, str] = {
    "basic": (
        "Ask a simple, concept-based question that checks the candidate's understanding of the core principles in this skill."
        "Ensure the question is clear, direct, and helps assess grasp of the basics rather than complex application."

    ),
    "intermediate": (
        "Ask a moderately challenging question that requires the candidate to apply concepts or explain reasoning with an example."
        "The question should connect related ideas and test both understanding and practical thinking."
    ),
    "advanced": (
        "Ask a challenging, real-world question that tests the candidate's ability to analyze scenarios, design efficient solutions,"
        "and reason about trade-offs. The question should encourage problem-solving and decision-making at an advanced level."
    ),
}


def _make_skill_prompt(skill: str, level: str, prev_responses: List[str], count: int) -> str:
    ctx = "\n".join(prev_responses[-2:]) if prev_responses else ""
    prompt = (
        f"Generate exactly {count} {level} interview questions for the skill: {skill}.\n"
        f"Guidance: {LEVEL_PROMPTS[level]}\n"
        "Structure requirements:\n"
        "- Q1: Conceptual (definition or contrast with a closely related concept).\n"
        "- Q2: Applied scenario (practical use under realistic constraints).\n"
        "- Q3: Debugging/Design (find a bug, trade-off, or design decision under load).\n"
        "Formatting constraints: each question must be a single bullet starting with '- ', a single sentence, and end with '?'.\n"
        "Avoid vague verbs (no 'explain', 'talk about'); prefer verbs like 'define', 'choose', 'design', 'optimize'.\n"
    )
    if ctx:
        prompt += f"Consider these last responses as context:\n{ctx}\n"
    prompt += "Return questions as a bullet list with exactly three bullets."
    return prompt


def run_skills_interaction(store: SessionStore, skills: List[str], play_audio: bool = True) -> None:
    stt = SpeechToText()

    for skill in skills:
        level_order = ["basic", "intermediate", "advanced"]
        current_index = 0
        level_results: Dict[str, Dict] = {}

        while current_index < len(level_order):
            level = level_order[current_index]
            prompt = _make_skill_prompt(skill, level, store.get_last_responses("skills", 2), 3)
            raw = generate_text(prompt)
            # Parse list of questions from bullets
            questions: List[str] = []
            for line in (raw or "").splitlines():
                line = line.strip("-• ")
                if not line:
                    continue
                if not line.endswith("?") and len(line) > 8:
                    line += "?"
                questions.append(line)
            if len(questions) < 3:
                questions += [
                    f"What does {skill} mean in your own words?",
                    f"Describe a use case where {skill} is essential.",
                    f"What common pitfalls do you watch for with {skill}?",
                ]
                questions = questions[:3]

            passes = 0
            fails = 0
            for q in questions:
                text_to_speech(q, play=play_audio)
                answer = stt.listen(timeout=8.0, phrase_time_limit=90.0)
                score = score_answer(q, answer)
                store.add_qa("skills", q, answer, score)
                if score >= 60:
                    passes += 1
                else:
                    fails += 1

            # Decide progression for this level
            passed_level = passes >= 2
            level_results[level] = {
                "passes": passes,
                "fails": fails,
                "passed_level": passed_level,
            }
            store.add_skill_result(skill, level, passed_level, level_results[level])

            if not passed_level and fails >= 2:
                # Mark not proficient and stop progressing for this skill
                break
            else:
                current_index += 1

from typing import List, Dict, Any
import numpy as np
from sentence_transformers import SentenceTransformer
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from processors.text_chunker import TextChunk
from config import Config
from logger import get_logger

class EmbeddingGenerator:
    def __init__(self, model_name: str = None):
        self.model_name = model_name or Config.EMBEDDING_MODEL
        self.model = None
        self._load_model()
    
    def _load_model(self):
        try:
            self.model = SentenceTransformer(self.model_name)
        except Exception as e:
            get_logger('EmbeddingGenerator').error("Error loading embedding model: %s", e)
            try:
                self.model = SentenceTransformer('all-MiniLM-L6-v2')
            except Exception as e2:
                raise RuntimeError(f"Failed to load embedding model: {e2}")
    
    def generate_embeddings(self, chunks: List[TextChunk]) -> List[Dict[str, Any]]:
        if not chunks:
            return []
        
        texts = [chunk.content for chunk in chunks]
        
        try:
            embeddings = self.model.encode(texts, convert_to_tensor=False)
            
            embedding_docs = []
            for chunk, embedding in zip(chunks, embeddings):
                doc = {
                    'id': f"{chunk.source}_{chunk.section}_{chunk.metadata.get('chunk_index', 0)}",
                    'content': chunk.content,
                    'embedding': embedding.tolist(),
                    'metadata': {
                        'source': chunk.source,
                        'section': chunk.section,
                        'token_count': chunk.token_count,
                        'chunk_index': chunk.metadata.get('chunk_index', 0),
                        **chunk.metadata
                    }
                }
                embedding_docs.append(doc)
            
            return embedding_docs
            
        except Exception as e:
            raise RuntimeError(f"Error generating embeddings: {e}")
    
    def generate_query_embedding(self, query_text: str) -> np.ndarray:
        if not query_text or not query_text.strip():
            raise ValueError("Query text cannot be empty")
        
        try:
            embedding = self.model.encode([query_text.strip()], convert_to_tensor=False)
            return embedding[0]
        except Exception as e:
            raise RuntimeError(f"Error generating query embedding: {e}")
    
    def get_model_info(self) -> Dict[str, Any]:
        if not self.model:
            return {}
        
        return {
            'model_name': self.model_name,
            'max_seq_length': getattr(self.model, 'max_seq_length', 'unknown'),
            'embedding_dimension': self.model.get_sentence_embedding_dimension(),
        }